package uok.stu.Harvestlink.service.impl;

import uok.stu.Harvestlink.service.NotificationSender;

public class NotificationSenderImpl implements NotificationSender {
}
