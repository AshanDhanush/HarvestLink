package uok.stu.Harvestlink.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uok.stu.Harvestlink.model.dto.CreateNotificationRequest;
import uok.stu.Harvestlink.model.dto.CreateNotificationResponce;
import uok.stu.Harvestlink.model.entity.Notification;
import uok.stu.Harvestlink.repository.NotificationRepository;
import uok.stu.Harvestlink.service.NotificationService;

import java.util.Date;

@Service
public class NotificationServiceImpl implements NotificationService {
    @Autowired
    NotificationRepository repo;
    @Override
    public CreateNotificationResponce create(CreateNotificationRequest req) {
        if (req.getIdempotencyKey() != null) {
            var existing = repo.findByIdempotencyKey(req.getIdempotencyKey());
            if (existing.isPresent()) {
                return new CreateNotificationResponce(existing.get().getId(), existing.get().getStatus());
            }
        }

        Notification notif = Notification.builder()
                .userId(req.getUserId())
                .channel(req.getChannel())
                .payload(req.getPayload())
                .status("queued")
                .attempts(0)
                .createdAt(new Date())
                .updatedAt(new Date())
                .idempotencyKey(req.getIdempotencyKey())
                .build();

        Notification saved = repo.save(notif);

        // Publish to queue
        sender.sendToQueue(saved);

        return new CreateNotificationResponce(saved.getId(), saved.getStatus());

    }
}
