package uok.stu.Harvestlink.service;

import uok.stu.Harvestlink.model.dto.CreateNotificationRequest;

public interface SMTPEmailService {
    void sendEmail(CreateNotificationRequest req);
}
