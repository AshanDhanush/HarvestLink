package uok.stu.Harvestlink.service.impl;


import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import uok.stu.Harvestlink.service.SMTPEmailService;

@Service
@RequiredArgsConstructor
public class SmtpEmailServiceImpl  implements SMTPEmailService {

    private final JavaMailSender mailSender;

    /**
     * Send an email with optional attachment.
     * @param to Recipient email
     * @param subject Email subject
     * @param body Email body text
     * @param attachmentName File name (e.g., "invoice.pdf")
     * @param attachmentData Byte[] content of the file
     */
    public void sendEmailWithAttachment(
            String to,
            String subject,
            String body,
            String attachmentName,
            byte[] attachmentData
    ) throws MessagingException {

        MimeMessage message = mailSender.createMimeMessage();

        // true = multipart for attachments
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        helper.setTo(to);
        helper.setSubject(subject);
        helper.setText(body, false);
        helper.setFrom("yourgmail@gmail.com");

        // If there is an attachment, add it
        if (attachmentName != null && attachmentData != null) {
            helper.addAttachment(
                    attachmentName,
                    new ByteArrayResource(attachmentData)
            );
        }

        mailSender.send(message);
    }
}

}
