package uok.stu.Harvestlink.consumer;

import lombok.RequiredArgsConstructor;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uok.stu.Harvestlink.model.entity.Notification;
import uok.stu.Harvestlink.repository.NotificationRepository;
import uok.stu.Harvestlink.service.SMTPEmailService;

@Service
@RequiredArgsConstructor
public class NotificationConsumer {
    @Autowired
     NotificationRepository repo;
    @Autowired
    SMTPEmailService SMTPEmailService;

    @RabbitListener(queues = "notification.email.queue")
    public void listenEmail(Notification n) {
        try {
            System.out.println("Sending email to: " + n.getToUser());

            SMTPEmailService.sendEmail(n.getToUser(),n.getSubject(),n.getBody(),n.);

            n.setStatus("delivered");
            n.setLastError(null);
            repo.save(n);

        } catch (Exception e) {
            n.setStatus("failed");
            n.setAttempts(n.getAttempts() + 1);
            n.setLastError(e.getMessage());
            repo.save(n);

            throw new RuntimeException(e);
        }
    }

}
