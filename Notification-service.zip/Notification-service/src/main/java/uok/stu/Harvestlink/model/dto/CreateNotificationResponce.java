package uok.stu.Harvestlink.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class CreateNotificationResponce {
    private String id;
    private String status;
}
