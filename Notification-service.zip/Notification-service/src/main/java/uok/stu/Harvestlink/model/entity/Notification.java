package uok.stu.Harvestlink.model.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.Date;

@Document(collation = "notifications")
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder

public class Notification {

    @Id
    private String id;
    private String toUser;     // recipient email
    private String subject;
    private String body;
    private String channel;    // email, sms, push

    private String status = "pending";
    private int attempts = 0;
    private String lastError;


    private String attachmentName; // e.g. "invoice.pdf"
    private byte[] attachmentData; // content

    private LocalDateTime createdAt = LocalDateTime.now();


}
