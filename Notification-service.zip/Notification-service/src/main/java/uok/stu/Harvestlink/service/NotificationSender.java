package uok.stu.Harvestlink.service;

public interface NotificationSender {
}
